package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class car {
	public engine engine;
    public car(engine engine) {
    	this.engine=engine;
    }
    public String drive() {
    	return engine.start();
    }
}
