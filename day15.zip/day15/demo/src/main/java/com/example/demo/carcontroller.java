package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class carcontroller {
    private car car;
    
    public carcontroller(car car) {
    	this.car=car;
    }
    @GetMapping("/drive")
    public String drivecar()
    {
    	return car.drive();
    }
}
