package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class engine {
    public String start()
     {
    	 return "engine start";
     }
}
