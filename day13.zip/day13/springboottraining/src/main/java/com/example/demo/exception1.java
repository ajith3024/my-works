package com.example.demo;

public class exception1 {
     public static void main(String[] args) {
		try {
			int a[ ] = {10,20,30};
		    System.out.println(a[0]);
		    System.out.println(a[1]);
		    System.out.println(a[2]);
		    System.out.println(a[3]);
		    System.out.println(10/0);
			
		}catch (ArithmeticException e ){
			System.out.println("JKFSKGBKSKG"+e);
		}catch (ArrayIndexOutOfBoundsException e1) {
			System.out.println("fbgbfsbgjkg"+ e1);
		}
	}
}
