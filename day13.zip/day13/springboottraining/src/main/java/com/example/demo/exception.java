package com.example.demo;

public class exception {
     public static void main(String[] args) {
		try {
			
			System.out.println("10/0");
			System.out.println ("kjsdilhugusg");
			
			
		}catch(Exception e){
			System.out.println ("an exception occured");
			
		}
	}
      
}
