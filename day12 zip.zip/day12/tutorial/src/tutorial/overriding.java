package tutorial;

class Child {

	void m1()
	{
		System.out.println("method m1 fsdasdfsdfaro paarent clas");
	}
}

public class overriding extends Child {
	void m1()
	{
		System.out.println("method m1 fsdasdfsdfaro child clas");
	}
   public static void main(String[] args) {
	   overriding xy = new overriding();
      xy.m1();
  
	
}
}