package tutorial;

public class pen {
	public pen() {
		System.out.println("hello world");// TODO Auto-generated constructor stub
	}
	void renold() {
		System.out.println("renold price : 10");
	}
    
    public static void main(String[] args) {
	pen details=new pen();
	details.renold();
	}
}
