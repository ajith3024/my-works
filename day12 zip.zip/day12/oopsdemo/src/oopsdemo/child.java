package oopsdemo;

public class child {
	class grandfather() {
		 system.out.println("i am grandfather of child");
	}
	class father() {
		 system.out.println("i am father of child");
	}   
     
	public static void main(String[] args) {
		child data=new child();
		
	}
}
