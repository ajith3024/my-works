import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './app.html'
})
export class AppComponent {

  num1!: number;
  num2!: number;
  result: number | null = null;

  add() {
    if (this.valid()) {
      this.result = this.num1 + this.num2;
    }
  }

  subtract() {
    if (this.valid()) {
      this.result = this.num1 - this.num2;
    }
  }

  valid(): boolean {
    return this.num1 !== null && this.num2 !== null;
  }
}